<template>
  <div class="list">
    <h1>List</h1>
  </div>
</template>

<style></style>
